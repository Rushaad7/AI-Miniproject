from bird import preprocessing as pp

pp.preprocess_data_set("datasets/birdClef2016Subset/valid",
                    "datasets/birdClef2016Subset_preprocessed/valid")
